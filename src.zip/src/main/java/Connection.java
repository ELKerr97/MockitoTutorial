public class Connection {

    java.sql.Connection openConnection(){

        return null;
    }

    void closeConnection(){

    }
}
